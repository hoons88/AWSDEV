<? include "../header.php";?>
<? include "sub_img.php";?>
<? include "sub_menu.php";?>
<article>
	<h1>Notice</h1>
		<table id="notice">
			<tr>
				<th scope="col" class="tno">No.</th>
				<th scope="col" class="ttitle">Title</th>
				<th scope="col" class="twriter">Writer</th>
				<th scope="col" class="tdata">Date</th>
				<th scope="col" class="tread">Read</th>
			</tr>
			<tr>
				<td>1</td>
				<td class="left">eget vehicula metus. In euismod sollicitudin lorem eu aliquet.</td>
				<td>Host Admin</td>
				<td>2016.01.11</td>
				<td>1600</td>
			</tr>
			<tr>
				<td>1</td>
				<td class="left">eget vehicula metus. In euismod sollicitudin lorem eu aliquet.</td>
				<td>Host Admin</td>
				<td>2016.01.11</td>
				<td>1600</td>
			</tr>
			<tr>
				<td>1</td>
				<td class="left">eget vehicula metus. In euismod sollicitudin lorem eu aliquet.</td>
				<td>Host Admin</td>
				<td>2016.01.11</td>
				<td>1600</td>
			</tr>
			<tr>
				<td>1</td>
				<td class="left">eget vehicula metus. In euismod sollicitudin lorem eu aliquet.</td>
				<td>Host Admin</td>
				<td>2016.01.11</td>
				<td>1600</td>
			</tr>
			<tr>
				<td>1</td>
				<td class="left">eget vehicula metus. In euismod sollicitudin lorem eu aliquet.</td>
				<td>Host Admin</td>
				<td>2016.01.11</td>
				<td>1600</td>
			</tr>
		</table>
		<div id="table_search">
			<input name="" type="text" class="input_box">
			<input type="button" value="search" class="btn">
		</div>
		 <div class="clear"></div>
 
<div id="page_control">
	<a href="#">Prev</a> 
	<a href="#">1</a> 
	<a href="#">2</a> 
	<a href="#">3</a> 
	<a href="#">4</a> 
	<a href="#">5</a> 
	<a href="#">6</a> 
	<a href="#">7</a> 
	<a href="#">8</a> 
	<a href="#">9</a> 
	<a href="#">10</a>  
	<a href="#">Next</a>
</div>
</article>
<? include "../footer.php";?>