	<footer>
			<hr>
			
			<div id="copy">
			Copyright 2016 kyes Inc. all rights reserved 
			contact mail : kys8502@naver.com Tel: +82 010-1234-1234
			</div>
			<div id="social">
				<img src="../images/facebook.gif" width="33" height="33" alt="Facebook">
				<img src="../images/twitter.gif" width="33" height="33" alt="twitter">
				
			</div>
			
		</footer>
	</div><!-- wrap -->
	</body>
</html>